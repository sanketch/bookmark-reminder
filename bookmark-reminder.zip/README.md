bookmark-reminder
=================

A Chrome extension that allows you to add a page as an event on Google Calendar, acting as a reminder to come back.

Uses the Google Calendar API 
